create view CS_student(sno,sname,sex,dept_no,age) AS (
	select * from student where dept_no=10);