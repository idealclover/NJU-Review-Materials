select sname,age from student,dept 
where student.dept_no=dept.dept_no and dept.dname='�Ź�' and age<=21 and sex='f'; 