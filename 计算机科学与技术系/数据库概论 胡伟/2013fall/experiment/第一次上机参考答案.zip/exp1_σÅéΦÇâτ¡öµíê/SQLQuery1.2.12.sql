select student.sno,grade from student,sc 
where student.sno=sc.sno and not exists  
	(select * from sc sc2 where sc.cno=sc2.cno and sc.grade<sc2.grade);