select sno from student 
where not exists (select * from sc sc1 where sc1.sno=1001 and not exists(
	select * from sc sc2 where sc2.sno=student.sno and sc2.cno=sc1.cno));