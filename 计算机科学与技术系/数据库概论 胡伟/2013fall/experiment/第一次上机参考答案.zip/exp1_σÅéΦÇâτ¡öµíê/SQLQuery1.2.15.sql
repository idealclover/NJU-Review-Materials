update sc set grade=grade+2 where cno in (
	select cno from course,teacher where course.tno=teacher.tno and cname='���ݽṹ' and tname='����');