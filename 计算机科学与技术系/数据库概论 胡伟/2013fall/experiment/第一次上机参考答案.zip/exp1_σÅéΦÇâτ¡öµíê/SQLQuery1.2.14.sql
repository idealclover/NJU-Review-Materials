select sname from student 
where not exists (
	select * from course,teacher where course.tno=teacher.tno and tname='����' and not exists (
		select * from sc where sc.sno=student.sno and sc.cno=course.cno));