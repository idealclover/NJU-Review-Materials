create table student(
	sno int not null primary key,
	sname char(8) not null,
	sex char(2),
	dept_no int
);