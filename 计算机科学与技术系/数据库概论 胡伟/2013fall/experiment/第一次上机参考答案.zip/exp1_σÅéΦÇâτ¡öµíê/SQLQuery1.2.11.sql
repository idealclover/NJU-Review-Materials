select sname from student 
where not exists (select sc.sno from sc,course 
                  where sc.cno=course.cno and sc.sno=student.sno 
                  group by sc.sno having SUM(credit)>=10);