create table teacher(
	tno int not null primary key,
	tname char(8) not null,
	dept_no int
);