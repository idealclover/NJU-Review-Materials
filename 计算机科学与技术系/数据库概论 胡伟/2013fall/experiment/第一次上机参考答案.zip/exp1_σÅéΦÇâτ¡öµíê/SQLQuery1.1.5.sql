create table dept(
	dept_no int not null,
	dname char(20) not null,
	primary key (dept_no)
);