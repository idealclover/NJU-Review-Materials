create table course(
	cno int not null,
	cname char(20) not null,
	tno int not null,
	credit int,
	primary key (cno,tno)
);