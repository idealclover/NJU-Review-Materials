create table sc(
	sno int not null,
	cno int not null,
	grade int,
	primary key (sno,cno)
);